﻿using System;

namespace Loja.UI.Pecadus.Admin
{
    public partial class PalavrasBuscadas : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}