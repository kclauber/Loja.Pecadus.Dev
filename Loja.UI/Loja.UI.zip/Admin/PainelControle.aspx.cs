﻿using System;
using Loja.Persistencia;
using Loja.Util;

namespace Loja.UI.Pecadus.Admin
{
    public partial class PainelControle : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
            }
        }
    }
}